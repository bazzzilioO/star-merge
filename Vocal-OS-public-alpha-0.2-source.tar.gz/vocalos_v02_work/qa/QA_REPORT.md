# Vocal OS Public Alpha 0.2 — QA snapshot

## Static / UI
- JavaScript syntax: PASS (Node 22 `--check`)
- HTML duplicate IDs: PASS (129 unique IDs)
- Inline event handlers resolve to functions: PASS
- AndroidManifest / launcher / styles XML parsing: PASS
- View routing: Home / Trainer / Games / Lab / Library: PASS
- Trainer sub-tabs: Trainer / Reference / Auto Pianist / Courses / Quick: PASS
- Studio sub-tabs: Pitch / Tests / Record / Tempo: PASS
- Game overlay open/close: PASS
- Responsive horizontal overflow: PASS at 320, 360, 393, 768 px widths
- Browser page errors in static interaction smoke test: 0

## Trainer logic
- Auto root uses calibrated comfort range when available.
- Target pattern is converted into timed note blocks.
- User pitch frames are aligned to note windows with configurable latency compensation.
- Per-note scoring includes pitch center, arrival and stability.
- Good synthetic frames score above poor/off-center frames in unit smoke test.
- Listen -> Sing separates reference playback from the scored voice pass.
- Guide / silent target / blind modes remain available.

## Pitch detector synthetic smoke test
Equivalent YIN/CMND detector logic was exercised on generated signals from ~82 Hz to 880 Hz using:
- pure sine
- multi-harmonic voice-like signal
- weak fundamental / strong second harmonic

Observed octave errors in this synthetic set: 0.
This is not a substitute for a physical-device microphone matrix.

## Still requires physical-device QA
- built-in mic vs wired headset mic
- Bluetooth latency and routing
- low-end / noisy Android devices
- high soprano / low bass extremes
- vibrato, fry, breathy phonation, distortion/grit
- speaker bleed in Guide mode
- OS permission denial / revoke / resume flows
- long sessions / battery / thermal behavior
