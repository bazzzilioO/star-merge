package com.arka.vocal;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Process;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int MIC_PERMISSION_REQUEST = 42;
    private WebView webView;
    private AudioEngine audioEngine;
    private String pendingMicAction = null;
    private MediaPlayer mediaPlayer;
    private ToneEngine toneEngine;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(9, 10, 12));
        window.setNavigationBarColor(Color.rgb(9, 10, 12));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9, 10, 12));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(100);

        audioEngine = new AudioEngine();
        toneEngine = new ToneEngine();
        webView.addJavascriptInterface(new AudioBridge(), "AudioBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private boolean hasMicPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMic(String action) {
        pendingMicAction = action;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != MIC_PERMISSION_REQUEST) return;
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        sendJs("window.onMicPermission && window.onMicPermission(" + granted + ");");
        if (granted && pendingMicAction != null) {
            String action = pendingMicAction;
            pendingMicAction = null;
            if ("analyze".equals(action)) audioEngine.start();
            if ("record".equals(action)) audioEngine.startRecording();
        } else {
            pendingMicAction = null;
        }
    }

    private void sendJs(String js) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private static String jsString(String value) {
        if (value == null) return "null";
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n") + "\"";
    }

    public class AudioBridge {
        @JavascriptInterface
        public boolean hasMicPermission() {
            return MainActivity.this.hasMicPermission();
        }

        @JavascriptInterface
        public void requestMicPermission() {
            runOnUiThread(() -> requestMic(null));
        }

        @JavascriptInterface
        public void startAnalyzer() {
            runOnUiThread(() -> {
                if (hasMicPermission()) audioEngine.start();
                else requestMic("analyze");
            });
        }

        @JavascriptInterface
        public void stopAnalyzer() {
            audioEngine.stopIfIdle();
        }

        @JavascriptInterface
        public boolean isAnalyzerRunning() {
            return audioEngine.isRunning();
        }

        @JavascriptInterface
        public void startRecording() {
            runOnUiThread(() -> {
                if (hasMicPermission()) audioEngine.startRecording();
                else requestMic("record");
            });
        }

        @JavascriptInterface
        public void stopRecording() {
            audioEngine.stopRecording();
        }

        @JavascriptInterface
        public boolean isRecording() {
            return audioEngine.isRecording();
        }

        @JavascriptInterface
        public boolean hasLastRecording() {
            File f = audioEngine.getLastRecording();
            return f != null && f.exists();
        }

        @JavascriptInterface
        public String getLastRecordingName() {
            File f = audioEngine.getLastRecording();
            return f == null ? "" : f.getName();
        }

        @JavascriptInterface
        public long getLastRecordingDurationMs() {
            return audioEngine.getLastRecordingDurationMs();
        }

        @JavascriptInterface
        public void playLastRecording() {
            runOnUiThread(() -> playRecording(audioEngine.getLastRecording()));
        }

        @JavascriptInterface
        public void stopPlayback() {
            runOnUiThread(MainActivity.this::stopPlayback);
        }

        @JavascriptInterface
        public void playTone(double frequency, int durationMs, String waveform, double volume) {
            if (toneEngine != null) toneEngine.playTone(frequency, durationMs, waveform, volume);
        }

        @JavascriptInterface
        public void startDrone(double frequency, String waveform, double volume) {
            if (toneEngine != null) toneEngine.startDrone(frequency, waveform, volume);
        }

        @JavascriptInterface
        public void stopDrone() {
            if (toneEngine != null) toneEngine.stopDrone();
        }

        @JavascriptInterface
        public boolean isDroneRunning() {
            return toneEngine != null && toneEngine.isDroneRunning();
        }
    }

    private void playRecording(File file) {
        if (file == null || !file.exists()) {
            sendJs("window.onPlaybackState && window.onPlaybackState(false);");
            return;
        }
        stopPlayback();
        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(file.getAbsolutePath());
            mediaPlayer.setOnCompletionListener(mp -> {
                sendJs("window.onPlaybackState && window.onPlaybackState(false);");
                stopPlayback();
            });
            mediaPlayer.prepare();
            mediaPlayer.start();
            sendJs("window.onPlaybackState && window.onPlaybackState(true);");
        } catch (IOException e) {
            stopPlayback();
            sendJs("window.onPlaybackState && window.onPlaybackState(false);");
        }
    }

    private void stopPlayback() {
        if (mediaPlayer != null) {
            try { mediaPlayer.stop(); } catch (Exception ignored) {}
            mediaPlayer.release();
            mediaPlayer = null;
        }
        sendJs("window.onPlaybackState && window.onPlaybackState(false);");
    }

    private class ToneEngine {
        private static final int TONE_RATE = 44100;
        private volatile boolean droneRunning = false;
        private volatile double droneFrequency = 440.0;
        private volatile String droneWaveform = "soft";
        private volatile double droneVolume = 0.25;
        private Thread droneThread;
        private AudioTrack droneTrack;

        boolean isDroneRunning() { return droneRunning; }

        void playTone(double frequency, int durationMs, String waveform, double volume) {
            final double f = Math.max(45.0, Math.min(1800.0, frequency));
            final int ms = Math.max(60, Math.min(5000, durationMs));
            final String wave = waveform == null ? "soft" : waveform;
            final double vol = Math.max(0.0, Math.min(1.0, volume));
            new Thread(() -> {
                int count = Math.max(1, (int) (TONE_RATE * ms / 1000.0));
                short[] pcm = new short[count];
                double phase = 0.0;
                double inc = 2.0 * Math.PI * f / TONE_RATE;
                for (int i = 0; i < count; i++) {
                    double env = 1.0;
                    int fade = Math.min(count / 4, (int) (TONE_RATE * 0.018));
                    if (fade > 0 && i < fade) env = i / (double) fade;
                    if (fade > 0 && i > count - fade) env = Math.max(0.0, (count - i) / (double) fade);
                    pcm[i] = (short) (32767.0 * vol * 0.72 * env * waveSample(phase, wave));
                    phase += inc;
                }
                int min = AudioTrack.getMinBufferSize(TONE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC, TONE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, pcm.length * 2), AudioTrack.MODE_STATIC);
                try {
                    track.write(pcm, 0, pcm.length);
                    track.play();
                    Thread.sleep(ms + 80L);
                } catch (Exception ignored) {
                } finally {
                    try { track.stop(); } catch (Exception ignored) {}
                    track.release();
                }
            }, "ArkaToneOneShot").start();
        }

        synchronized void startDrone(double frequency, String waveform, double volume) {
            stopDrone();
            droneFrequency = Math.max(45.0, Math.min(1800.0, frequency));
            droneWaveform = waveform == null ? "soft" : waveform;
            droneVolume = Math.max(0.0, Math.min(1.0, volume));
            droneRunning = true;
            droneThread = new Thread(this::droneLoop, "ArkaDrone");
            droneThread.start();
            sendJs("window.onDroneState && window.onDroneState(true);");
        }

        synchronized void stopDrone() {
            droneRunning = false;
            if (droneTrack != null) {
                try { droneTrack.stop(); } catch (Exception ignored) {}
            }
            if (droneThread != null && Thread.currentThread() != droneThread) {
                try { droneThread.join(180); } catch (InterruptedException ignored) {}
            }
            droneThread = null;
            if (droneTrack != null) {
                try { droneTrack.release(); } catch (Exception ignored) {}
                droneTrack = null;
            }
            sendJs("window.onDroneState && window.onDroneState(false);");
        }

        private void droneLoop() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
            int min = AudioTrack.getMinBufferSize(TONE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int frames = Math.max(1024, min / 2);
            short[] pcm = new short[frames];
            AudioTrack local = new AudioTrack(AudioManager.STREAM_MUSIC, TONE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min * 2, frames * 4), AudioTrack.MODE_STREAM);
            synchronized (this) { droneTrack = local; }
            double phase = 0.0;
            try {
                local.play();
                while (droneRunning) {
                    double inc = 2.0 * Math.PI * droneFrequency / TONE_RATE;
                    for (int i = 0; i < frames; i++) {
                        pcm[i] = (short) (32767.0 * droneVolume * 0.55 * waveSample(phase, droneWaveform));
                        phase += inc;
                        if (phase > Math.PI * 2.0) phase -= Math.PI * 2.0;
                    }
                    local.write(pcm, 0, frames);
                }
            } catch (Exception ignored) {
            } finally {
                synchronized (this) {
                    if (droneTrack == local) droneTrack = null;
                }
                try { local.stop(); } catch (Exception ignored) {}
                local.release();
            }
        }

        private double waveSample(double phase, String wave) {
            double s = Math.sin(phase);
            if ("sine".equals(wave)) return s;
            if ("triangle".equals(wave)) return (2.0 / Math.PI) * Math.asin(s);
            if ("saw".equals(wave)) {
                double x = phase / (2.0 * Math.PI);
                return 2.0 * (x - Math.floor(x + 0.5));
            }
            // Soft harmonic reference: clearer fundamental than a raw sine, less harsh than saw.
            return 0.78 * s + 0.16 * Math.sin(phase * 2.0) + 0.06 * Math.sin(phase * 3.0);
        }
    }

    private class AudioEngine {
        private static final int SAMPLE_RATE = 44100;
        private static final int FRAME_SIZE = 2048;
        private final Object recordLock = new Object();
        private final Deque<Double> stableHistory = new ArrayDeque<>();

        private volatile boolean running = false;
        private volatile boolean recording = false;
        private Thread audioThread;
        private AudioRecord audioRecord;
        private FileOutputStream pcmOut;
        private File tempPcm;
        private File lastRecording;
        private long recordingStartedAt = 0L;
        private long lastRecordingDurationMs = 0L;
        private int historyMidi = Integer.MIN_VALUE;
        private long lastPitchDispatch = 0L;

        boolean isRunning() { return running; }
        boolean isRecording() { return recording; }
        File getLastRecording() { return lastRecording; }
        long getLastRecordingDurationMs() { return lastRecordingDurationMs; }

        @SuppressLint("MissingPermission")
        synchronized void start() {
            if (running) return;
            if (!hasMicPermission()) return;
            int minBuffer = AudioRecord.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
            );
            int bufferBytes = Math.max(minBuffer, FRAME_SIZE * 4);
            audioRecord = new AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    bufferBytes
            );
            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                audioRecord.release();
                audioRecord = null;
                sendJs("window.onAnalyzerError && window.onAnalyzerError('Не удалось открыть микрофон');");
                return;
            }
            running = true;
            audioThread = new Thread(this::audioLoop, "ArkaPitchEngine");
            audioThread.start();
            sendJs("window.onAnalyzerState && window.onAnalyzerState(true);");
        }

        void stopIfIdle() {
            if (!recording) stop();
        }

        synchronized void stop() {
            running = false;
            if (audioRecord != null) {
                try { audioRecord.stop(); } catch (Exception ignored) {}
            }
            if (audioThread != null) {
                try { audioThread.join(350); } catch (InterruptedException ignored) {}
                audioThread = null;
            }
            if (audioRecord != null) {
                audioRecord.release();
                audioRecord = null;
            }
            stableHistory.clear();
            historyMidi = Integer.MIN_VALUE;
            sendJs("window.onAnalyzerState && window.onAnalyzerState(false);");
        }

        void startRecording() {
            if (!hasMicPermission()) return;
            start();
            synchronized (recordLock) {
                if (recording) return;
                try {
                    File dir = new File(getFilesDir(), "recordings");
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("mkdir failed");
                    tempPcm = new File(dir, "capture_" + System.currentTimeMillis() + ".pcm");
                    pcmOut = new FileOutputStream(tempPcm);
                    recordingStartedAt = System.currentTimeMillis();
                    recording = true;
                    sendJs("window.onRecordingState && window.onRecordingState(true);");
                } catch (IOException e) {
                    recording = false;
                    sendJs("window.onAnalyzerError && window.onAnalyzerError('Не удалось начать запись');");
                }
            }
        }

        void stopRecording() {
            File pcm = null;
            synchronized (recordLock) {
                if (!recording) return;
                recording = false;
                lastRecordingDurationMs = Math.max(0L, System.currentTimeMillis() - recordingStartedAt);
                try {
                    if (pcmOut != null) pcmOut.close();
                } catch (IOException ignored) {}
                pcmOut = null;
                pcm = tempPcm;
                tempPcm = null;
            }
            if (pcm != null && pcm.exists()) {
                File wav = new File(pcm.getParentFile(), "ARKA_" + System.currentTimeMillis() + ".wav");
                try {
                    pcmToWav(pcm, wav);
                    if (!pcm.delete()) pcm.deleteOnExit();
                    lastRecording = wav;
                    sendJs("window.onRecordingSaved && window.onRecordingSaved(" +
                            jsString(wav.getName()) + "," + lastRecordingDurationMs + ");");
                } catch (IOException e) {
                    sendJs("window.onAnalyzerError && window.onAnalyzerError('Не удалось сохранить WAV');");
                }
            }
            sendJs("window.onRecordingState && window.onRecordingState(false);");
        }

        private void audioLoop() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
            short[] frame = new short[FRAME_SIZE];
            byte[] writeBytes = new byte[FRAME_SIZE * 2];
            try {
                audioRecord.startRecording();
                while (running) {
                    int read = audioRecord.read(frame, 0, frame.length);
                    if (read <= 0) continue;

                    if (recording) {
                        synchronized (recordLock) {
                            if (recording && pcmOut != null) {
                                int p = 0;
                                for (int i = 0; i < read; i++) {
                                    short s = frame[i];
                                    writeBytes[p++] = (byte) (s & 0xff);
                                    writeBytes[p++] = (byte) ((s >> 8) & 0xff);
                                }
                                try { pcmOut.write(writeBytes, 0, read * 2); } catch (IOException ignored) {}
                            }
                        }
                    }

                    PitchResult pitch = detectPitch(frame, read);
                    long now = System.currentTimeMillis();
                    if (now - lastPitchDispatch >= 75) {
                        lastPitchDispatch = now;
                        if (pitch == null) {
                            stableHistory.clear();
                            historyMidi = Integer.MIN_VALUE;
                            sendJs("window.onPitchSilence && window.onPitchSilence();");
                        } else {
                            int roundedMidi = (int) Math.round(pitch.midi);
                            double stability = updateStability(pitch.midi, roundedMidi);
                            double cents = (pitch.midi - roundedMidi) * 100.0;
                            sendJs(String.format(Locale.US,
                                    "window.onPitchUpdate && window.onPitchUpdate(%.3f,%.4f,%d,%.2f,%.4f,%.1f);",
                                    pitch.frequency, pitch.midi, roundedMidi, cents, pitch.rms, stability));
                        }
                    }
                }
            } catch (Exception e) {
                if (running) sendJs("window.onAnalyzerError && window.onAnalyzerError('Ошибка аудиодвижка');");
            } finally {
                try { if (audioRecord != null) audioRecord.stop(); } catch (Exception ignored) {}
            }
        }

        private double updateStability(double midiFloat, int roundedMidi) {
            if (roundedMidi != historyMidi) {
                stableHistory.clear();
                historyMidi = roundedMidi;
            }
            stableHistory.addLast(midiFloat * 100.0);
            while (stableHistory.size() > 16) stableHistory.removeFirst();
            if (stableHistory.size() < 4) return -1.0;
            double mean = 0.0;
            for (double x : stableHistory) mean += x;
            mean /= stableHistory.size();
            double variance = 0.0;
            for (double x : stableHistory) {
                double d = x - mean;
                variance += d * d;
            }
            variance /= stableHistory.size();
            double sdCents = Math.sqrt(variance);
            return Math.max(0.0, Math.min(100.0, 100.0 - sdCents * 4.0));
        }

        private PitchResult detectPitch(short[] samples, int length) {
            if (length < 1024) return null;
            double rms = 0.0;
            for (int i = 0; i < length; i++) {
                double v = samples[i] / 32768.0;
                rms += v * v;
            }
            rms = Math.sqrt(rms / length);
            if (rms < 0.012) return null;

            int minTau = SAMPLE_RATE / 1000;
            int maxTau = Math.min(SAMPLE_RATE / 70, length / 2);
            double[] diff = new double[maxTau + 1];
            for (int tau = 1; tau <= maxTau; tau++) {
                double sum = 0.0;
                int limit = length - tau;
                for (int i = 0; i < limit; i++) {
                    double d = samples[i] - samples[i + tau];
                    sum += d * d;
                }
                diff[tau] = sum;
            }

            double[] cmnd = new double[maxTau + 1];
            cmnd[0] = 1.0;
            double runningSum = 0.0;
            for (int tau = 1; tau <= maxTau; tau++) {
                runningSum += diff[tau];
                cmnd[tau] = runningSum > 0.0 ? diff[tau] * tau / runningSum : 1.0;
            }

            int bestTau = -1;
            double threshold = 0.16;
            for (int tau = minTau; tau <= maxTau; tau++) {
                if (cmnd[tau] < threshold) {
                    while (tau + 1 <= maxTau && cmnd[tau + 1] < cmnd[tau]) tau++;
                    bestTau = tau;
                    break;
                }
            }
            if (bestTau < 0) return null;

            double betterTau = bestTau;
            if (bestTau > minTau && bestTau < maxTau) {
                double s0 = diff[bestTau - 1];
                double s1 = diff[bestTau];
                double s2 = diff[bestTau + 1];
                double denom = 2.0 * (2.0 * s1 - s2 - s0);
                if (Math.abs(denom) > 1e-9) betterTau += (s2 - s0) / denom;
            }
            double frequency = SAMPLE_RATE / betterTau;
            if (frequency < 70.0 || frequency > 1000.0) return null;
            double midi = 69.0 + 12.0 * (Math.log(frequency / 440.0) / Math.log(2.0));
            return new PitchResult(frequency, midi, rms);
        }

        private void pcmToWav(File pcm, File wav) throws IOException {
            long dataSize = pcm.length();
            long byteRate = SAMPLE_RATE * 2L;
            try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(pcm));
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(wav))) {
                writeAscii(out, "RIFF");
                writeIntLE(out, (int) (36 + dataSize));
                writeAscii(out, "WAVE");
                writeAscii(out, "fmt ");
                writeIntLE(out, 16);
                writeShortLE(out, (short) 1);
                writeShortLE(out, (short) 1);
                writeIntLE(out, SAMPLE_RATE);
                writeIntLE(out, (int) byteRate);
                writeShortLE(out, (short) 2);
                writeShortLE(out, (short) 16);
                writeAscii(out, "data");
                writeIntLE(out, (int) dataSize);
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
        }

        private void writeAscii(BufferedOutputStream out, String value) throws IOException {
            out.write(value.getBytes("US-ASCII"));
        }
        private void writeIntLE(BufferedOutputStream out, int value) throws IOException {
            out.write(value & 0xff);
            out.write((value >> 8) & 0xff);
            out.write((value >> 16) & 0xff);
            out.write((value >> 24) & 0xff);
        }
        private void writeShortLE(BufferedOutputStream out, short value) throws IOException {
            out.write(value & 0xff);
            out.write((value >> 8) & 0xff);
        }
    }

    private static class PitchResult {
        final double frequency;
        final double midi;
        final double rms;
        PitchResult(double frequency, double midi, double rms) {
            this.frequency = frequency;
            this.midi = midi;
            this.rms = rms;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (audioEngine != null) {
            if (audioEngine.isRecording()) audioEngine.stopRecording();
            audioEngine.stop();
        }
        stopPlayback();
        if (toneEngine != null) toneEngine.stopDrone();
    }

    @Override
    protected void onDestroy() {
        if (audioEngine != null) {
            if (audioEngine.isRecording()) audioEngine.stopRecording();
            audioEngine.stop();
        }
        stopPlayback();
        if (toneEngine != null) toneEngine.stopDrone();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
