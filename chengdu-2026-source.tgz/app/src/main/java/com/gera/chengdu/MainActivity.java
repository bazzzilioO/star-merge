package com.gera.chengdu;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;


public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(10, 13, 14));
        window.setNavigationBarColor(Color.rgb(10, 13, 14));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(10, 13, 14));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.addJavascriptInterface(new NativeBridge(this), "Native");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme) || "market".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ignored) { }
                    return true;
                }
                return false;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public static class NativeBridge {
        private final Activity activity;
        NativeBridge(Activity activity) { this.activity = activity; }

        @JavascriptInterface
        public void copy(String text) {
            ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Чэнду", text));
            activity.runOnUiThread(() -> Toast.makeText(activity, "Скопировано", Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void openMap(String query) {
            String encoded = Uri.encode(query);
            Uri uri = Uri.parse("https://uri.amap.com/search?keyword=" + encoded + "&callnative=1");
            open(uri);
        }

        @JavascriptInterface
        public void openDidi(String destination) {
            copy(destination);
            Intent launch = activity.getPackageManager().getLaunchIntentForPackage("com.sdu.didi.psnger");
            if (launch != null) activity.startActivity(launch);
            else open(Uri.parse("market://details?id=com.sdu.didi.psnger"));
        }

        @JavascriptInterface
        public void setAlarm(int hour, int minute, String label) {
            Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, hour)
                    .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            try { activity.startActivity(intent); }
            catch (ActivityNotFoundException e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Приложение будильника не найдено", Toast.LENGTH_SHORT).show());
            }
        }

        @JavascriptInterface
        public void share(String text) {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text);
            activity.startActivity(Intent.createChooser(send, "Поделиться"));
        }

        @JavascriptInterface
        public void openUrl(String url) { open(Uri.parse(url)); }

        private void open(Uri uri) {
            try { activity.startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (ActivityNotFoundException e) {
                activity.runOnUiThread(() -> Toast.makeText(activity, "Не удалось открыть", Toast.LENGTH_SHORT).show());
            }
        }
    }
}
